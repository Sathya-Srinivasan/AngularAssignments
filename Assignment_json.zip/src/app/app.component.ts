import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div>

  <h1>{{pageHeader}}</h1>

  <app-child [students]="students"></app-child>

  </div>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Welcome to Nested Components';
  pageHeader = 'Welcome to Nested Components';
  students: any[] = 

  [

    { Name: 'Raj', Branch: 'ECE', Mobile: 123456789, Gender: 'Male', Age: 22 },

    { Name: 'Sen', Branch: 'CSE', Mobile: 987654321, Gender: 'Female', Age: 33 },

    { Name: 'Pra', Branch: 'CIV', Mobile: 147852369, Gender: 'Female', Age: 24 },

    { Name: 'Sim', Branch: 'EEE', Mobile: 369852147, Gender: 'Male', Age: 28 },

  ];

}
